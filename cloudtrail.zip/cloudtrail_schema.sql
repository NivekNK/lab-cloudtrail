DROP DATABASE IF EXISTS cloudtrail_relational;
CREATE DATABASE IF NOT EXISTS cloudtrail_relational;
USE cloudtrail_relational;

-- --- 1. TABLAS MAESTRAS ---

CREATE TABLE IF NOT EXISTS event_names (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) UNIQUE NOT NULL -- $.EventName / $.CloudTrailEvent.eventName [cite: 1, 3]
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS event_sources (
    id INT AUTO_INCREMENT PRIMARY KEY,
    source VARCHAR(255) UNIQUE NOT NULL -- $.EventSource / $.CloudTrailEvent.eventSource [cite: 1, 3]
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS user_agents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    agent TEXT NOT NULL -- $.CloudTrailEvent.userAgent [cite: 3, 5]
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS regions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) UNIQUE NOT NULL -- $.CloudTrailEvent.awsRegion [cite: 3]
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS event_types (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) UNIQUE NOT NULL -- $.CloudTrailEvent.eventType [cite: 3, 8]
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS event_categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) UNIQUE NOT NULL -- $.CloudTrailEvent.eventCategory [cite: 3, 8]
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS error_codes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(255) UNIQUE NOT NULL -- $.CloudTrailEvent.errorCode [cite: 107, 124]
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS invocation_sources (
    id INT AUTO_INCREMENT PRIMARY KEY,
    invoker VARCHAR(255) UNIQUE NOT NULL -- $.CloudTrailEvent.userIdentity.invokedBy [cite: 13, 14]
) ENGINE=InnoDB;


-- --- 2. ENTIDADES (DEDUPLICACIÓN) ---

CREATE TABLE IF NOT EXISTS identities (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_name VARCHAR(255),       -- $.Username [cite: 2, 4]
    type VARCHAR(100),            -- $.CloudTrailEvent.userIdentity.type [cite: 2, 8]
    principal_id VARCHAR(200),    -- $.CloudTrailEvent.userIdentity.principalId [cite: 2]
    arn VARCHAR(400),              -- $.CloudTrailEvent.userIdentity.arn [cite: 2]
    account_id VARCHAR(100),       -- $.CloudTrailEvent.userIdentity.accountId [cite: 2, 8]
    access_key_id VARCHAR(64),     -- $.AccessKeyId / $.CloudTrailEvent.userIdentity.accessKeyId [cite: 1, 2]
    invoker_id INT,                -- FK -> invocation_sources.id [cite: 13]
    UNIQUE KEY unq_identity (principal_id, arn, access_key_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS issuers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    type VARCHAR(100),            -- $.CloudTrailEvent.userIdentity.sessionContext.sessionIssuer.type [cite: 2, 4]
    principal_id VARCHAR(200),    -- $.CloudTrailEvent.userIdentity.sessionContext.sessionIssuer.principalId [cite: 2, 4]
    arn VARCHAR(400),              -- $.CloudTrailEvent.userIdentity.sessionContext.sessionIssuer.arn [cite: 2, 4]
    user_name VARCHAR(255),       -- $.CloudTrailEvent.userIdentity.sessionContext.sessionIssuer.userName [cite: 2, 4]
    account_id VARCHAR(100),       -- $.CloudTrailEvent.userIdentity.sessionContext.sessionIssuer.accountId [cite: 2, 4]
    UNIQUE KEY unq_issuer (principal_id, arn)
) ENGINE=InnoDB;


-- --- 3. TABLA DE EVENTOS (HECHOS) ---

CREATE TABLE IF NOT EXISTS events (
    event_id VARCHAR(255) NOT NULL,        -- $.EventId / $.CloudTrailEvent.eventID [cite: 1, 3]
    event_time TIMESTAMP NOT NULL,         -- $.CloudTrailEvent.eventTime [cite: 3]
    event_time_epoch BIGINT,               -- $.EventTime (Formato epoch) [cite: 1]
    
    -- Relaciones (IDs)
    event_name_id INT NOT NULL,
    source_id INT NOT NULL,
    region_id INT NOT NULL,
    identity_id INT NOT NULL,
    issuer_id INT,
    user_agent_id INT,
    error_code_id INT,
    type_id INT,                           -- CORREGIDO: Columna faltante
    category_id INT,                       -- CORREGIDO: Columna faltante
    
    -- Metadata técnica
    request_id VARCHAR(255),               -- $.CloudTrailEvent.requestID [cite: 3, 5]
    shared_event_id VARCHAR(255),          -- $.CloudTrailEvent.sharedEventID [cite: 8, 13]
    recipient_account_id VARCHAR(100),     -- $.CloudTrailEvent.recipientAccountId [cite: 3, 8]
    source_ip VARCHAR(100),                -- $.CloudTrailEvent.sourceIPAddress [cite: 3, 8]
    vpc_endpoint_id VARCHAR(255),          -- $.CloudTrailEvent.vpcEndpointId [cite: 73]
    event_version VARCHAR(10),             -- $.CloudTrailEvent.eventVersion [cite: 2, 13]
    
    -- Flags y Seguridad
    read_only TINYINT(1) DEFAULT 0,        -- $.ReadOnly [cite: 1, 3]
    management_event TINYINT(1) DEFAULT 0, -- $.CloudTrailEvent.managementEvent [cite: 3, 8]
    mfa_authenticated TINYINT(1) DEFAULT 0,-- $.CloudTrailEvent.userIdentity.sessionContext.attributes.mfaAuthenticated [cite: 2]
    session_creation_date DATETIME,        -- $.CloudTrailEvent.userIdentity.sessionContext.attributes.creationDate [cite: 2]
    include_all_instances TINYINT(1) DEFAULT 0, -- $.CloudTrailEvent.requestParameters.includeAllInstances [cite: 72]
    
    -- Campos Dinámicos JSON
    request_parameters JSON,               -- $.CloudTrailEvent.requestParameters [cite: 3, 5]
    response_elements JSON,                -- $.CloudTrailEvent.responseElements [cite: 3, 13]
    additional_event_data JSON,            -- $.CloudTrailEvent.additionalEventData [cite: 13, 94]
    service_event_details JSON,            -- $.CloudTrailEvent.serviceEventDetails [cite: 8, 48]
    tls_details JSON,                      -- $.CloudTrailEvent.tlsDetails [cite: 3, 5]
    error_message TEXT,                    -- $.CloudTrailEvent.errorMessage [cite: 107, 124]

    PRIMARY KEY (event_id, event_time)
) ENGINE=InnoDB;


-- --- 4. DETALLE DE RECURSOS ---

CREATE TABLE IF NOT EXISTS event_resources (
    id INT AUTO_INCREMENT,
    event_id VARCHAR(255) NOT NULL,
    event_time TIMESTAMP NOT NULL,
    resource_type VARCHAR(255),            -- $.Resources[].ResourceType [cite: 9, 29]
    resource_name VARCHAR(1000),           -- $.Resources[].ResourceName [cite: 9, 29]
    account_id VARCHAR(100),               -- $.CloudTrailEvent.resources[].accountId [cite: 8, 13]
    PRIMARY KEY (id, event_time)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS ingestion_log (
    ingested_date DATE PRIMARY KEY,
    execution_time DATETIME NOT NULL
) ENGINE=InnoDB;
